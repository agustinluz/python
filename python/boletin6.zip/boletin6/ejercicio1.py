#Escribe un programa que escriba los 100 primeros números naturales en el archivo numeros.txt.

with open("fichero1.txt", encoding="utf-8", mode="w") as fichero:
    for i in range(1, 101):
        fichero.write(str(i) + "\n")