#Implementar un programa que permita realizar la operación de copia de un fichero. Tanto origen.txt como destino.txt serán ficheros de texto cuyos nombres indicará el usuario por teclado.

#Se debe utilizar readline() para la lectura del fichero origen y comprobar su existencia con os.path.isfile ()
import os
def main():
    origen = input("Introduce el nombre del fichero origen: ")
    destino = input("Introduce el nombre del fichero destino: ")
    if os.path.isfile(origen):
        with open(origen, 'r') as f:
            contenido = f.read()
        with open(destino, 'w') as f:
            f.write(contenido)
        print(f"El fichero {origen} se ha copiado correctamente en {destino}")
    else:
        print(f"El fichero {origen} no existe")

if __name__ == "__main__":
    main()