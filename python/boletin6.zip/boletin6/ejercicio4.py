# Escriba un programa que se encargue de clasificar una serie de cadenas atendiendo a su longitud.
# Se solicitará al usuario el nombre del archivo que contendrá el conjunto de palabras, cada una en una línea.
# También se pedirá por teclado un valor entero que se utilizará como valor de corte para clasificar las palabras del archivo anterior.
# Las palabras con longitud menor al valor de corte se almacenarán en el fichero menor.txt
# y el resto de palabras en el fichero mayor.txt

def mostrarPalabras():
    with open("ficheroPalabras.txt", encoding="utf-8", mode="r") as f:
        for line in f:
            print(line.strip())
def clasificarPalabras():
    corte = int(input("Introduce el valor de corte: "))
    with open("ficheroPalabras.txt", encoding="utf-8", mode="r") as f:
        with open("menor.txt", encoding="utf-8", mode="w") as f_menor, open("mayor.txt", encoding="utf-8", mode="w") as f_mayor:
            for line in f:
                palabra = line.strip()
                if len(palabra) < corte:
                    f_menor.write(palabra + "\n")
                else:
                    f_mayor.write(palabra + "\n")
def main():
    mostrarPalabras()
    clasificarPalabras()
    print("Palabras clasificadas correctamente.")

if __name__ == "__main__":
    main()



