# Escribir una función, obtenerNumerosArchivo, que reciba por parámetro el nombre de un archivo
# que almacenará una serie de cantidades enteras y positivas (un número por línea).
# La función leerá todos los valores del archivo, calculará su suma y la devolverá.

def obtenerNumerosArchivo(archivo):
    suma_total = 0
    with open(archivo, encoding="UTF-8", mode="r") as f:
        for line in f:
            suma_total += int(line.strip())
    return suma_total

def main():
    archivo = input("Escribe el nombre del archivo a leer: ")
    suma = obtenerNumerosArchivo(archivo)
    print(f"La suma total es de: {suma}")

if __name__ == "__main__":
    main()