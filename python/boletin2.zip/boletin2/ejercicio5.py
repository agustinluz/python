

letra=input("Escribe la letra a contar: ")
frase = input("Escribe la frase que quieres: ")
cantidad= frase.count(letra)
print(f"En la frase introducida hay {cantidad} veces el caracter: {letra}")