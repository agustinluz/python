def pedirNumeros():
    num1 = int(input("Escribe el primer número para operar: "))
    num2 = int(input("Escribe el segundo número para operar: "))
    return num1, num2

def pedirDiv():
    num1 = int(input("Escribe el primer número para operar: "))
    num2 = 0
    while num2 == 0:  
        num2 = int(input("Escribe el segundo número para operar (distinto de 0): "))
    return num1, num2

resultado = 0
opc = 0

while opc != 5:
    print("\nMenú de operaciones:")
    print("1: SUMAR")
    print("2: RESTAR")
    print("3: MULTIPLICAR")
    print("4: DIVIDIR")
    print("5: SALIR")

    
    opc = int(input("Elige una opción: "))


    match opc:
        case 1: 
            num1, num2 = pedirNumeros()
            resultado = num1 + num2
            print(f"El resultado es: {resultado}")
        case 2:
            num1, num2 = pedirNumeros()
            resultado = num1 - num2
            print(f"El resultado es: {resultado}")
        case 3:
            num1, num2 = pedirNumeros()
            resultado = num1 * num2
            print(f"El resultado es: {resultado}")
        case 4:
            num1, num2 = pedirDiv()
            resultado = num1 / num2
            print(f"El resultado es: {resultado}")
        case 5:
            print("Saliendo del programa. ¡Hasta luego!")
        case _:
            print("Opción no válida. Inténtalo de nuevo.")
