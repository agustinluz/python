
repeticiones=int(input("Escribe las capas que quieres que tenga la piramide: "))
for i in range ( repeticiones):
    print("*"*(i+1))