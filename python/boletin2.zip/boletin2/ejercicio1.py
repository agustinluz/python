def operacion():
    num = 1
    suma=0
    media=0
    cantidad=0
    while (num!=0):
        num=int(input("Introduce numero a sumar, se para con el 0: "))        
        if(num!=0):
            suma+=num
            cantidad+=1
            media=suma/cantidad
    return suma, media
suma, media= operacion()
print(f"La suma de los numeros introducidos es: {suma} y la media: {media}")