edad = int(input("Escribe aquí tu edad: "))

if 0 < edad <= 4:
    print(f"Con {edad} años puedes entrar gratis a la sala.")
elif 4 < edad <= 18:
    print(f"Con {edad} años, para acceder a la sala has de pagar 5€.")
elif edad > 18:
    print(f"Con {edad} años, has de pagar 10€ para acceder a la sala.")
else:
    print("La edad ingresada no es válida.")
