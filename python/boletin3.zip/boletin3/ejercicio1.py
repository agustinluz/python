import random

def cuboycuadrado(numero):
    cuadrado = numero ** 2
    cubo = numero ** 3
    print(f"Número: {numero}, cuadrado: {cuadrado}, cubo: {cubo}")

lista = [cuboycuadrado(random.randint(1, 10)) for i in range(10)]
