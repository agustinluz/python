numeros = []
print("Introduce números (un número negativo para terminar):")
while (numero := int(input("Número: "))) >= 0:
    numeros.append(numero)

nueva_lista = []
for numero in numeros:
    if numero not in nueva_lista:
        nueva_lista.append(numero)

print("\nLista sin duplicados:")
print(nueva_lista)
