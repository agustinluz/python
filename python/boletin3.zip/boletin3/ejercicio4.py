tempe_min = [1, 1, 8, 9, 12]
tempe_max = [9, 15, 16, 22, 22]

temp_media = [print(f"Temperatura media día {i+1}: {(tempe_min[i] + tempe_max[i]) / 2}ºC") for i in range(5)]

min_temp = min(tempe_min)

dias_menor_temp = [ i+1 for i, v in enumerate(tempe_min) if v == min_temp]

print(f"El día o días con temperatura minima son: {dias_menor_temp}")


tempMax=int(input("Escribe aqui la temperatura maxima que quieres buscar: "))
dias_mas_temp = [ i+1 for i in range(len(tempe_max)) if tempMax == tempe_max[i]]

if(len(dias_mas_temp)==0):
    print(f"No hay ningun día con {tempMax}ºC como temperatura maxima")
else:
    print(f"El día o días con {tempMax}ºC como temperatura maxima son los dias: {dias_mas_temp}")
