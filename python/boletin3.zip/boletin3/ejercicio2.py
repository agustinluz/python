

lista=[int(input("Escribe tu nota comprendida entre 0 y 10: ")) for i in range(5)]
print(f"Notas: {lista} \nMedia: {sum(lista)/len(lista)} \nMax: {max(lista)} Min: {min(lista)}")