def crear_tabla():
    print("Introduce los valores para la tabla (5x5):")
    return [[int(input(f"Valor para [{i+1}, {j+1}]: ")) for j in range(5)] for i in range(5)]

def mostrar_tabla(tabla):
    print("\nTabla ingresada:")
    for fila in tabla:
        print(fila)

def calcular_sumas(tabla):
    sumas_filas = [sum(fila) for fila in tabla]
    sumas_columnas = [sum(fila[j] for fila in tabla) for j in range(5)]
    return sumas_filas, sumas_columnas

tabla = crear_tabla()
mostrar_tabla(tabla)

sumas_filas, sumas_columnas = calcular_sumas(tabla)

print("\nSuma de cada fila:")
for i, suma in enumerate(sumas_filas):
    print(f"Fila {i+1}: {suma}")

print("\nSuma de cada columna:")
for j, suma in enumerate(sumas_columnas):
    print(f"Columna {j+1}: {suma}")
