def mostrarMenu():
    print("\nOpciones:")
    print("1. Contar")
    print("2. Modificar")
    print("3. Eliminar")
    print("4. Mostrar")
    print("5. Terminar")

def main():
    # Crear la lista de palabras
    palabras = []
    print("Introduce palabras para crear la lista (escribe 'fin' para terminar):")
    while (palabra := input("Palabra: ").lower()) != "fin":
        palabras.append(palabra)

    while True:
        mostrarMenu()
        opcion = input("Elige una opción (1-5): ")

        if opcion == "1":  
            cadena = input("¿Qué palabra quieres contar? ")
            print(f"La palabra '{cadena}' aparece {palabras.count(cadena)} veces.")
        elif opcion == "2":  
            antigua = input("¿Qué palabra quieres modificar? ")
            nueva = input("¿Por qué palabra la quieres cambiar? ")
            palabras = [nueva if palabra == antigua else palabra for palabra in palabras]
            print(f"Se han modificado todas las apariciones de '{antigua}' por '{nueva}'.")
        elif opcion == "3":  
            cadena = input("¿Qué palabra quieres eliminar? ")
            palabras = [palabra for palabra in palabras if palabra != cadena]
            print(f"Se han eliminado todas las apariciones de '{cadena}'.")
        elif opcion == "4": 
            print("\nLista de palabras:")
            print(palabras)
        elif opcion == "5": 
            print("¡Hasta luego!")
            break
        else:
            print("Opción no válida. Inténtalo de nuevo.")

main()
