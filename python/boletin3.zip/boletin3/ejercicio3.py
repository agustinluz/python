import random
lista= [random.randint(0,100) for i in range(10)]
lista.sort()
print(lista)